﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prKol_ind_Zad6._9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string infix = "((A+B)C-D)";
            string prefix = InfixToPrefix(infix);

            Console.WriteLine($"Инфиксная форма {infix}");
            Console.WriteLine($"Префиксная форма {prefix}");
            Console.ReadKey();
        }
        static string InfixToPrefix(string infix)
        {
            string reversedInfix = new string(infix.Reverse().ToArray());
            Stack<char> op = new Stack<char>();
            string output = "";
            foreach (char c in reversedInfix)
            {
                if (char.IsLetterOrDigit(c))
                {
                    output = c + output;
                }
                else if (c == ')')
                {
                    op.Push(c);
                }
                else if (c == '(')
                {
                    while (op.Count > 0 && op.Peek() != ')')
                    {
                        output = op.Pop() + output;
                    }

                    if (op.Count > 0)
                    {
                        op.Pop();
                    }
                }
                else
                {
                    while (op.Count > 0 && Prec(c) < Prec(op.Peek()))
                    {
                        output = op.Pop() + output;
                    }
                    op.Push(c);
                }
            }

            while (op.Count > 0)
            {
                output = op.Pop() + output;
            }

            return output;
        }
        static int Prec(char c)
        {
            if (c == '-' || c == '+')
            {
                return 1;
            }
            else if (c == ' ' || c == '/')
            {
                return 2;
            }
            return 0;
        }

    }
}

