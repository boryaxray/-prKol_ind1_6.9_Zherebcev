﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad9_queue
{
    internal class Student
    {
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string Patronymic { get; set; }
        public string GroupNumber { get; set; }
        public int[] Grades { get; set; }
        public override string ToString()
        {
            return $"{LastName} {FirstName} {Patronymic}, group: {GroupNumber}, grades: {string.Join(", ", Grades)}";
        }
    }
}
