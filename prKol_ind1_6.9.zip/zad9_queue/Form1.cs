﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zad9_queue
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<Student> students = new List<Student>();
            button1.Visible= false;
            if (File.Exists("students.txt"))
            {
                using (StreamReader sr = new StreamReader("students.txt"))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] data = line.Split(',');
                        Student student = new Student
                        {
                            LastName = data[0],
                            FirstName = data[1],
                            Patronymic = data[2],
                            GroupNumber = data[3],
                            Grades = data.Skip(4).Select(int.Parse).ToArray()
                        };
                        students.Add(student);
                    }
                }
            }
            else MessageBox.Show("Файл не найден!");

            Queue<Student> passed = new Queue<Student>();
            Queue<Student> failed = new Queue<Student>();
            foreach (Student student in students)
            {
                if (student.Grades.All(grade => grade >= 4))
                {
                    passed.Enqueue(student);
                }
                else
                {
                    failed.Enqueue(student);
                }
            }
            ListBox listBox = new ListBox();
            listBox.Dock = DockStyle.Fill;
            listBox.Items.Add("УСПЕШНО СДАЛИ:");
            Controls.Add(listBox);
            foreach (Student student in passed)
            {
                listBox.Items.Add(student);
            }
            listBox.Items.Add("ОСТАЛЬНЫЕ СТУДЕНТЫ:");
            foreach (Student student in failed)
            {
                listBox.Items.Add(student);
            }

        }
    }
}
